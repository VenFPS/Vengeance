void SCR_CaptureVideo_Ogg_Init(void);
qboolean SCR_CaptureVideo_Ogg_Available(void);
void SCR_CaptureVideo_Ogg_BeginVideo(void);
void SCR_CaptureVideo_Ogg_CloseDLL(void);
